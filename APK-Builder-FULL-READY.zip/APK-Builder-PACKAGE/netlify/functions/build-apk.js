exports.handler = async function(event) {
  if (event.httpMethod !== 'POST') return {statusCode:405, body:JSON.stringify({error:'Method not allowed'})};
  try {
    const body = JSON.parse(event.body || '{}');
    if (!body.sourceBase64) return {statusCode:400,body:JSON.stringify({error:'HTML/ZIP file missing'})};
    const token = process.env.GITHUB_TOKEN;
    const repo = process.env.GITHUB_REPO;
    const workflow = process.env.GITHUB_WORKFLOW || 'build-apk.yml';
    const branch = process.env.GITHUB_BRANCH || 'main';
    if (!token || !repo) return {statusCode:500,body:JSON.stringify({error:'Netlify environment variables GITHUB_TOKEN and GITHUB_REPO are not configured'})};
    const buildId = 'b' + Date.now() + Math.random().toString(36).slice(2,8);
    const response = await fetch(`https://api.github.com/repos/${repo}/actions/workflows/${workflow}/dispatches`, {
      method:'POST', headers:{'Authorization':`Bearer ${token}`,'Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28','Content-Type':'application/json'},
      body:JSON.stringify({ref:branch, inputs:{buildId, sourceName:String(body.sourceName||'index.html'), sourceBase64:String(body.sourceBase64), settingsBase64:Buffer.from(JSON.stringify(body.settings||{})).toString('base64')}})
    });
    if (!response.ok) { const t=await response.text(); throw new Error(`GitHub dispatch failed (${response.status}): ${t.slice(0,300)}`); }
    return {statusCode:200,body:JSON.stringify({buildId,message:'GitHub Actions build started'})};
  } catch(e) { return {statusCode:500,body:JSON.stringify({error:e.message||'Server error'})}; }
};
