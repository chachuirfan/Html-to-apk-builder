exports.handler = async function(event) {
  try {
    const buildId = (event.queryStringParameters||{}).buildId;
    if (!buildId) return {statusCode:400,body:JSON.stringify({status:'failed',message:'buildId missing'})};
    const token=process.env.GITHUB_TOKEN, repo=process.env.GITHUB_REPO, workflow=process.env.GITHUB_WORKFLOW||'build-apk.yml';
    if(!token||!repo) return {statusCode:500,body:JSON.stringify({status:'failed',message:'GitHub environment variables are not configured'})};
    const headers={'Authorization':`Bearer ${token}`,'Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28'};
    const ar=await fetch(`https://api.github.com/repos/${repo}/actions/artifacts?per_page=100`,{headers});
    if(!ar.ok) throw new Error(`GitHub artifacts request failed (${ar.status})`);
    const data=await ar.json();
    const artifact=(data.artifacts||[]).find(a=>a.name===`apk-${buildId}`);
    if(artifact && !artifact.expired) {
      const rr=await fetch(`https://api.github.com/repos/${repo}/actions/artifacts/${artifact.id}/zip`,{headers,redirect:'manual'});
      const loc=rr.headers.get('location');
      if(loc) return {statusCode:200,body:JSON.stringify({status:'completed',progress:100,message:'APK ready',downloadUrl:loc})};
    }
    const rr=await fetch(`https://api.github.com/repos/${repo}/actions/runs?per_page=50`,{headers});
    if(!rr.ok) throw new Error(`GitHub runs request failed (${rr.status})`);
    const runs=await rr.json();
    const candidates=(runs.workflow_runs||[]).filter(r=>r.path===`.github/workflows/${workflow}` || r.name);
    const recent=candidates[0];
    if(recent) {
      if(recent.conclusion && recent.conclusion!=='success') return {statusCode:200,body:JSON.stringify({status:'failed',progress:100,message:`GitHub build ${recent.conclusion}`})};
      if(recent.status==='completed') return {statusCode:200,body:JSON.stringify({status:'failed',progress:100,message:'Build completed but APK artifact was not found'})};
      return {statusCode:200,body:JSON.stringify({status:'building',progress:45,message:'⏳ GitHub Actions is building the APK…'})};
    }
    return {statusCode:200,body:JSON.stringify({status:'building',progress:20,message:'⏳ Build request is being processed…'})};
  } catch(e){ return {statusCode:500,body:JSON.stringify({status:'building',progress:20,message:e.message||'Status check failed'})}; }
};
