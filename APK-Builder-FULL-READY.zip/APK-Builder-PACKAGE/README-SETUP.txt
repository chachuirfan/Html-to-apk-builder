HTML TO APK BUILDER — APK BUILD PACKAGE
Made by Irfan Aslam

IMPORTANT:
The existing index.html/design/settings are preserved. This package adds the Netlify Functions and GitHub Actions workflow required for real APK builds.

Required one-time setup:
1) Put this whole folder in a GitHub repository (the workflow file must remain at .github/workflows/build-apk.yml).
2) Deploy the same repository/site to Netlify.
3) In Netlify Site configuration > Environment variables, add:
   GITHUB_TOKEN = a GitHub token with permission to trigger Actions and read/download Actions artifacts for this repository.
   GITHUB_REPO = OWNER/REPOSITORY (example: irfan123/my-apk-builder)
   Optional: GITHUB_BRANCH = main
   Optional: GITHUB_WORKFLOW = build-apk.yml
4) Redeploy the Netlify site after adding variables.
5) Open the builder, select HTML/ZIP, press Build APK, wait for the status to reach 100%, then press Download APK.

Do NOT put the GitHub token inside index.html.
